function [PFX,PFY,Regionsize, Best]=PartFilter(PFX,PFY,Regionsize,MatriceImage,HistoTarget)

% It�ration du filtre de particules
% [PFX,PFY,Regionsize,Best]=PartFilter(PFX,PFY,Regionsize,MatriceImage,HistoTarget)
%***************************************************            
% Auteur: Guillaume-Alexandre Bilodeau          
% Param�tres: 
% PFX: Position en X des particules
% PFY: Position en Y des particules
% Regionsize: Taille des particules (carr�)
% MatriceImage: Image
% HistoTarget: Mod�le de l'objet � suivre
% Best: Vecteur �tat. Position et taille de la meilleure particule
%***************************************************

Probab=[];

%Calcul de la similitude pour chaque particule
for i=1:length(PFX)
    
    %Isole la r�gion dans l'image
    [TRX,TRY,BLX,BLY]=TrouveROI(PFX(i),PFY(i),Regionsize(i),size(MatriceImage,1),size(MatriceImage,1));
    ROIMasque=zeros(size(MatriceImage,1),size(MatriceImage,2));
    ROIMasque([TRX:BLX],[TRY:BLY])=1;
    SubImage=MatriceImage.*uint8(ROIMasque);

    %Calcul l'histogramme de la r�gion
    HistoTemp=zeros(1,64);
    SubImage=double(SubImage);
    SubImage(SubImage==0)=SubImage(SubImage==0)+300;
    for k=0:63
        HistoTemp(k+1)=sum(SubImage(SubImage==k*4))+sum(SubImage(SubImage==(k+1)*4))+sum(SubImage(SubImage==(k+2)*4))+sum(SubImage(SubImage==(k+3)*4));
    end
    HistoTemp=HistoTemp/sum(HistoTemp); %Normalisation

    %Comparaison avec histotarget (Distance bhattacharyya)
    Probab(i)=-log(sum(sqrt(HistoTemp.*HistoTarget)));
    %pause;
end

%Trouve la meilleure particule, et trouve le poids de chaque particule.

Probab(Probab>1)=1;
Probab=1-Probab;
Probab;
[Val,Pos]=max(Probab);
Best=[PFX(Pos),PFY(Pos),Regionsize(Pos)];
[TRX,TRY,BLX,BLY]=TrouveROI(PFX(Pos),PFY(Pos),Regionsize(Pos),size(MatriceImage,1),size(MatriceImage,1));

%Affichage de la meilleure particule
figure(1)
imshow(MatriceImage)
rectangle('Position',[TRY,TRX,Regionsize(Pos),Regionsize(Pos)],'EdgeColor','w')
pause(0.3);

% %G�n�ration des nouvelles particules

TempMat=[Probab' PFX' PFY' Regionsize'];
TempMat=sortrows(TempMat,-1);

%Cr�ation des intervalles.
chance(1)=TempMat(1,1);
for i=2:length(TempMat)
    chance(i)=chance(i-1)+TempMat(i,1);
end
%pause;
k=1;
for i=1:length(PFX)
    % Tire un nombre et v�rifie dans quel intervalle il est.
    partchanceuse=rand*chance(end);
    for j=1:length(chance)
        if chance(j)>partchanceuse
            break
        end
    end
    if j>1 
        j=j-1;
    end
    NPFX(i)=TempMat(j,2)+round(2*TempMat(j,4)*(rand-0.5));
    NPFY(i)=TempMat(j,3)+round(2*TempMat(j,4)*(rand-0.5));
    NRegionsize(k)=TempMat(j,4)+round(TempMat(j,4)/3*rand);

    if NPFX(i)<1
        NPFX(i)=1;
    end
    if NPFX(i)>size(MatriceImage,1)
        NPFX(i)=size(MatriceImage,1);
    end      
    if NPFY(i)<1
        NPFY(i)=1;
    end
    if NPFY(i)>size(MatriceImage,2)
        NPFY(i)=size(MatriceImage,2);
    end      
end

%Valeurs de retour. 
PFX=NPFX(1:length(PFX));
PFY=NPFY(1:length(PFX));
Regionsize=Regionsize(1:length(PFX));


   
