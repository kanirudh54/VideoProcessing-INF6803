clear

%Initilisation
PFinit=false; %Pour v�rifier si le filtre de particules est initialis�.
PFX=0;
PFY=0;
histogramme=zeros(1,64);

%Param�tres: nombre de particules et taille de d�part
Regionsize=30;
nbparticles=10;

%Ouverture du fichier vid�o
nomfichier=input('Entrez le nom de fichier: ','s');
%nomfichier='face.avi';
info=mmfileinfo(nomfichier)
Video=mmreader(nomfichier);
NbFrames=get(Video,'numberOfFrames')

i=1;

while i<NbFrames
    imagevid=rgb2gray(read(Video,i)); %Obtient une trame
    datavid=imagevid(:,:,1);
    if PFinit==true
        %Affichage des particules pour la trame courante
        figure(2)
        imshow(uint8(datavid))
        for ii=1:nbparticles
            [TRX,TRY,BLX,BLY]=TrouveROI(PFX(ii),PFY(ii),Regionsize(ii),size(datavid,1),size(datavid,2));
            rectangle('Position',[TRY,TRX,Regionsize(ii),Regionsize(ii)],'EdgeColor','w')
        end
        pause(0.5)

        %Applique une it�ration du filtre de particule
        [PFX,PFY,Regionsize,Best]=PartFilter(PFX,PFY,Regionsize,datavid,histogramme);
    else
       imshow(datavid);
       %Pour la s�lection de la r�gion d'int�r�t
       a=input('Faire une s�lection (o/n)?','s')
       if(isequal(a,'o'))
           BW=roipoly(datavid);
           datavid=double(datavid);
           datavid(BW==0)=datavid(BW==0)+300; %Pour ignorer les pixels hors de la r�gion d'int�r�t.
           
           %Calcul de l'histogramme: Mod�lisation par histogramme
           for k=0:63
               histogramme(k+1)=sum(datavid(datavid==k*4))+sum(datavid(datavid==(k+1)*4))+sum(datavid(datavid==(k+2)*4))+sum(datavid(datavid==(k+3)*4));
           end

           %histogramme normalis�. C'est notre mod�le.
           histogramme=histogramme/sum(histogramme);
           
           %Cr�ation d'une image � 2 niveaux (trouve BLOB)
           BW(BW>0)=255;
           
           %Trouve le centre du BLOB pour d�finir la premi�re particule. En
           %fait, on red�finit ici la r�gion d'int�r�t pour quelle ait la
           %taille d'une particule.
           [PFX,PFY]=TrouveCentroide(BW);
           [PFX,PFY, Regionsize]=InitPF(round(PFX),round(PFY),Regionsize,nbparticles);
           PFinit=true;
           %Affichage des particules initiales
           figure(1)
           datavid=imagevid(:,:,1);
           imshow(uint8(datavid))
           for ii=1:nbparticles
                rectangle('Position',[PFY(ii),PFX(ii),Regionsize(ii),Regionsize(ii)],'EdgeColor','w')
           end
           pause(0.5)
       end       
    end
    i=i+1 %Prochaine trame.
end


    
