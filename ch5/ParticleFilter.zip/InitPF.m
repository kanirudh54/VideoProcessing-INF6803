function [PFX,PFY,Regionsize]=InitPF(PFX,PFY,Regionsize,nbparticles)

% Fonction qui initialise les particules
% [ PFX,PFY,Regionsize ] = InitPF(PFX,PFY,Regionsize,nbparticles )
%***************************************************            
% Auteur: Guillaume-Alexandre Bilodeau          
% Param�tres: 
% PFX: Position en X des particules
% PFY: Position en Y des particules
% Regionsize: Taille des particules (carr�)
% nbparticules: Nombre de particules
%***************************************************

%G�n�ration de la premi�re particule 
PFX(1)=round(PFX(1)-Regionsize/2);
PFY(1)=round(PFY(1)-Regionsize/2);

%Position et taille al�atoire.
for i=2:nbparticles
    PFX(i)=PFX(1)+round(2*Regionsize(1)*(rand-0.5));
    PFY(i)=PFY(1)+round(2*Regionsize(1)*(rand-0.5));
    Regionsize(i)=Regionsize(1)+round(Regionsize(1)/3*rand);
end
