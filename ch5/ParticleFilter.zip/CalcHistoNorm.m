function [ Histo ] = CalcHistoNorm( SubImage )

% Calcul l'histogramme en fonction du noyau
% function [ Histo ] = CalcHistoNorm( SubImage )
%***************************************************            
% Auteur: Guillaume-Alexandre Bilodeau          
% Param�tres: 
% SubImage: R�gion d'image
% HistoTarget: Histogramme de la r�gion selon de noyau
%***************************************************

%Avec Kernel (lin�aire avec distance, max au centre):
Histo=zeros(1,256);
kernel=zeros(size(SubImage,1),size(SubImage,2));
for i=1:size(SubImage,1)
    for j=1:size(SubImage,2)
        dist=sqrt((i-size(SubImage,1)/2)^2+(j-size(SubImage,2)/2)^2);
        dist=dist/sqrt((size(SubImage,1)/2)^2+(size(SubImage,2)/2)^2);
        kernel(i,j)=3*(1-dist);
        
        Histo(SubImage(i,j)+1)=Histo(SubImage(i,j)+1)+kernel(i,j);
        
    end
end
% figure(2);
% mesh(kernel)
% pause

Histo=Histo/sum(Histo);