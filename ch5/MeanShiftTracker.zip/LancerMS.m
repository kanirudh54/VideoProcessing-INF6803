clear

MSinit=false;
MSX=0;
MSY=0;
histogramme=zeros(1,256);
Regionsize=80;

nomfichier=input('Entrez le nom de fichier: ','s');
%nomfichier='face.avi'
info=mmfileinfo(nomfichier)
Video=mmreader(nomfichier);
NbFrames=get(Video,'numberOfFrames')
i=1;

while i<NbFrames
    imagevid=rgb2gray(read(Video,i));
    datavid=imagevid(:,:,1);
    if MSinit==true
        [MSX,MSY,histogramme]=MeanShiftTracker(MSX,MSY,Regionsize,datavid,histogramme);
        %Calcul la r�gion d'int�r�t
        [TRX,TRY,BLX,BLY]=TrouveROI(MSX,MSY,Regionsize,size(datavid,1),size(datavid,2));
    else
       imshow(datavid);
       a=input('Faire une s�lection (o/n)?','s')
       if(isequal(a,'o'))
           BW=roipoly(datavid);
           datavid=double(datavid);
           datavid(BW==0)=datavid(BW==0)+300;
           %Calcul de l'histogramme
           for k=0:255
               histogramme(k+1)=sum(datavid(datavid==k));
           end
           histogramme=round((histogramme/sum(histogramme))*255);
           %Trouve le centre de BW (centroide)
           [MSX,MSY]=TrouveCentroide(BW);
           MSinit=true;
       end       
    end
    i=i+3 %aux 3 secondes
end


    
