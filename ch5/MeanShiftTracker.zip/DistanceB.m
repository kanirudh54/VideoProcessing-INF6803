function [dist]=DistanceB(Histo1, Histo2)

% Calcul la distance de Bhattacharyya
% function [dist]=DistanceB(Histo1, Histo2)
%***************************************************            
% Auteur: Guillaume-Alexandre Bilodeau          
% Param�tres: 
% Histo1, Histo2: Histogramme � comparer
% dist: distance calcul�e
%***************************************************

dist=sum(sqrt(Histo1.*Histo2));