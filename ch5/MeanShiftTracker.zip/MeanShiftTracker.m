function [Xout,Yout, Histogramme]=MeanShiftTracker(X,Y,Regionsize,MatriceImage,Histogramme)

% It�ration Mean-Shift
% function [Xout,Yout,Histogramme]=MeanShiftTracker(X,Y,Regionsize,MatriceImage,Histogramme)
%***************************************************            
% Auteur: Guillaume-Alexandre Bilodeau          
% Param�tres: 
% X,Xout: Position en X de la r�gion suivie
% Y,Yout: Position en Y de la r�gion suivie
% Regionsize: Taille de la r�gion suivie
% MatriceImage: Image
% Histogramme: Mod�le de l'objet � suivre
%***************************************************

Seuil=2; %en pixel
MotionX=Seuil+1;
MotionY=Seuil+1;

while MotionX>Seuil || MotionY>Seuil
   
    [TRX,TRY,BLX,BLY]=TrouveROI(X,Y,Regionsize,size(MatriceImage,1),size(MatriceImage,2));
    
    ROIMasque=zeros(size(MatriceImage,1),size(MatriceImage,2));
    ROIMasque([TRX:BLX],[TRY:BLY])=1;
    SubImage=MatriceImage.*uint8(ROIMasque);
    
    %Projection inverse de l'histogramme vers la patch d'images
    %Carte de probabilit�
    
    ProbabilityMap=SubImage;
    
    for i=TRX:BLX
        for j=TRY:BLY
            ProbabilityMap(i,j)=Histogramme(SubImage(i,j)+1);
        end
    end
    
    %Trouve le centroide
    oldX=X;
    oldY=Y;
    [X,Y]=TrouveCentroide(double(ProbabilityMap));
    
    AA=double(ProbabilityMap);
    AAA=(AA/max(max(AA)))*255;
    
    imshow(uint8(AAA))
    rectangle('Position',[TRY,TRX,Regionsize,Regionsize],'EdgeColor','r')
    hold on
    plot(Y,X,'*r')
    pause(0.2)
    
    hold off
    %condition fronti�re
    if isnan(X) || isnan(Y)
        X=oldX;
        Y=oldY;
    end
    
    %crit�re d'arr�t
    MotionX=abs(X-oldX);
    MotionY=abs(Y-oldY);
end

if X<1
    X=1;
end
if X>size(MatriceImage,1)
    X=size(MatriceImage,1);
end      
if Y<1
    Y=1;
end
if Y>size(MatriceImage,2)
    Y=size(MatriceImage,2);
end      

Xout=X;
Yout=Y;

%Mise � jour de l'histogramme pour la prochaine it�ration
HistoTemp=zeros(1,256);
SubImage=double(SubImage);
SubImage(SubImage==0)=SubImage(SubImage==0)+300;
for k=0:255
     HistoTemp(k+1)=sum(SubImage(SubImage==k));
end
HistoTemp=round((HistoTemp/sum(HistoTemp))*255); %Normalisation
%Mise � jour adaptative
%Histogramme(60:end)=round(Histogramme(60:end)*0.98+HistoTemp(60:end)*0.02);

%Affichage
figure(1)
imshow(MatriceImage)
rectangle('Position',[TRY,TRX,Regionsize,Regionsize])
pause(0.5)
   
    



