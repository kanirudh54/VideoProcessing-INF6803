function [TopRightX,TopRightY,BottomLeftX,BottomLeftY]=TrouveROI(X,Y,Regionsize,ImageX,ImageY)

% Fonction qui extrait la r�gion carr� courante
% [ PFX,PFY,Regionsize ] = InitPF(PFX,PFY,Regionsize,nbparticles )
%***************************************************            
% Auteur: Guillaume-Alexandre Bilodeau          
% Param�tres: 
% X et Y: Centre de la r�gion
% Regionsize: Taille de la r�gion (carr�)
% ImageX et ImageY: Taille de l'image
%***************************************************

if nargin==4
    ImageY=ImageX;
end

TopRightX=round(X-Regionsize/2);
TopRightY=round(Y-Regionsize/2);

BottomLeftX=TopRightX+Regionsize;
BottomLeftY=TopRightY+Regionsize;

%Conditions aux fronti�res
if BottomLeftX<1
    BottomLeftX=1;
end
if BottomLeftX>ImageX
    BottomLeftX=ImageX;
end      
if TopRightX<1
    TopRightX=1;
end
if TopRightX>ImageX
    TopRightX=ImageX;
end      
if BottomLeftY<1
    BottomLeftY=1;
end
if BottomLeftY>ImageY
    BottomLeftY=ImageY;
end      
if TopRightY<1
    TopRightY=1;
end
if TopRightY>ImageY
    TopRightY=ImageY;
end 
