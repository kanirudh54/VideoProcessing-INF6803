clear
MSinit=false;
MSX=0;
MSY=0;
histogramme=zeros(1,256);
Regionsize=60;

nomfichier=input('Entrez le nom de fichier: ','s');
%nomfichier='face.avi'
info=mmfileinfo(nomfichier)
Video=mmreader(nomfichier);
NbFrames=get(Video,'numberOfFrames')
i=1;

while i<NbFrames
    imagevid=rgb2gray(read(Video,i));
    datavid=imagevid(:,:,1);
    if MSinit==true
        %It�ration du tracker Kernel-based.
        [MSX,MSY,histogramme]=KernelTracker(MSX,MSY,Regionsize,datavid,histogramme);
    else
       %Initialisation
       imshow(datavid);
       a=input('Faire une s�lection (o/n)?','s')
       if(isequal(a,'o'))
           BW=roipoly(datavid);
           datavid=double(datavid);
           datavid(BW==0)=datavid(BW==0)+300;
           %Calcul de l'histogramme
           for k=0:255
               histogramme(k+1)=sum(datavid(datavid==k));
           end
           histogramme=histogramme/sum(histogramme);
           %Trouve le centre de BW (centroide)
           [MSX,MSY]=TrouveCentroide(BW);
           imagevid=rgb2gray(read(Video,i));
           datavid=imagevid(:,:,1);
           [TRX,TRY,BLX,BLY]=TrouveROI(MSX,MSY,Regionsize,size(datavid,1),size(datavid,2));
           SubImage=datavid([TRX:BLX],[TRY:BLY]);
           histogramme=CalcHistoNorm(SubImage);

           MSinit=true;
       end       
    end
    i=i+1 %aux 3 secondes
end


    
