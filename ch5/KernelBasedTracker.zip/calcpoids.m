function [Poids]= calcpoids(Histo1, Histo2)

% Calcul du poids pour chaque pixel dans la r�gion d'int�r�t
% function [Poids]= calcpoids(Histo1, Histo2)
%***************************************************            
% Auteur: Guillaume-Alexandre Bilodeau          
% Param�tres: 
% Histo1, Histo2: Histogramme � comparer
% Poids: poids pour chaque intervalle des histogrammes
%***************************************************

Poids=sqrt(Histo1./Histo2);