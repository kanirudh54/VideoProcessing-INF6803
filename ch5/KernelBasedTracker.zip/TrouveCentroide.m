function [X,Y]=TrouveCentroide(Matrice)

% Fonction qui trouve le centre de masse
% [X,Y]=TrouveCentroide(Matrice)
%***************************************************            
% Auteur: Guillaume-Alexandre Bilodeau          
% Param�tres: 
% Matrice: Une r�gion d'image
% X et Y: Le centre de masse
%***************************************************

% Trouve le centre de masse
TempX=0;
TempY=0;
SommeX=0;
SommeY=0;

%Par la m�thode des moments
for i=1:size(Matrice,1)
    for j=1:size(Matrice,2)
        TempX=TempX+Matrice(i,j)*i;
        SommeX=SommeX+Matrice(i,j); 
        TempY=TempY+Matrice(i,j)*j;
        SommeY=SommeY+Matrice(i,j); 
    end
end

X=TempX/SommeX;
Y=TempY/SommeY;