function [Xout,Yout, Histogramme]=KernelTracker(X,Y,Regionsize,MatriceImage,Histogramme)

%Algorithme Kernel-based tracker

Seuil=1; %en pixel
MotionX=Seuil+1;
MotionY=Seuil+1;

%Target model
Qu=Histogramme;

while MotionX>Seuil || MotionY>Seuil
   
    
    %Y0 de Comaniciu et al.
    [TRX,TRY,BLX,BLY]=TrouveROI(X,Y,Regionsize,size(MatriceImage,1),size(MatriceImage,2));
    SubImage=MatriceImage([TRX:BLX],[TRY:BLY]);
    
    %�tape 1:
    %Calcul de Pu
    PuY0=CalcHistoNorm(SubImage);
    RhoY0=DistanceB(PuY0,Qu);
    
    %�tape 2: Les poids
    wi=calcpoids(Qu,PuY0);
    
    %�tape 3: Next position
    
    ProbabilityMap=double(SubImage);
    
    for i=1:size(SubImage,1)
        for j=1:size(SubImage,2)
            ProbabilityMap(i,j)=wi(SubImage(i,j)+1);
        end
    end
    
    %Trouve le centroide
    oldX=X;
    oldY=Y;
    [X,Y]=TrouveCentroide(ProbabilityMap); %minimise la distance de bhattacharyaa
    X=X+TRX;
    Y=Y+TRY;
    
    AA=ProbabilityMap;
    AAA=(AA/max(max(AA)))*255;
    
    %condition fronti�re
    if isnan(X) || isnan(Y)
        X=oldX;
        Y=oldY;
    end
    
    %�tape 4: PuY1
    [TRX,TRY,BLX,BLY]=TrouveROI(X,Y,Regionsize,size(MatriceImage,1),size(MatriceImage,2));
    SubImage2=MatriceImage([TRX:BLX],[TRY:BLY]);
    
    PuY1=CalcHistoNorm(SubImage2);
    RhoY1=DistanceB(PuY1,Qu);
    
    MatImage2=MatriceImage;
    MatImage2([TRX:BLX],[TRY:BLY])=uint8(AAA); 
    imshow(MatImage2)
    rectangle('Position',[TRY,TRX,Regionsize,Regionsize],'EdgeColor','y')
    hold on
    plot(Y,X,'*r')
    pause(0.01)
    
    active=true;
    %�tape 5: RhoY0, RhoY1
    while RhoY1<RhoY0 && active
        X=(oldX+X)/2;
        Y=(oldY+Y)/2;
        
        [TRX,TRY,BLX,BLY]=TrouveROI(X,Y,Regionsize,size(MatriceImage,1),size(MatriceImage,2));
        SubImage2=MatriceImage([TRX:BLX],[TRY:BLY]);

        PuY1=CalcHistoNorm(SubImage2);
        RhoY1=DistanceB(PuY1,Qu);
        
        MatImage2=MatriceImage;
        MatImage2([TRX:BLX],[TRY:BLY])=uint8(AAA);  
        imshow(MatImage2)
        rectangle('Position',[TRY,TRX,Regionsize,Regionsize],'EdgeColor','r')
        hold on
        plot(Y,X,'*r')
        pause(0.01)
        
    end
    
    %�tape 6: Crit�re d'arr�t
    
    %crit�re d'arr�t
    MotionX=abs(X-oldX);
    MotionY=abs(Y-oldY);
end

if X<1
    X=1;
end
if X>size(MatriceImage,1)
    X=size(MatriceImage,1);
end      
if Y<1
    Y=1;
end
if Y>size(MatriceImage,2)
    Y=size(MatriceImage,2);
end      

Xout=X;
Yout=Y;

%Affichage
figure(1)
imshow(MatriceImage)
rectangle('Position',[TRY,TRX,Regionsize,Regionsize],'EdgeColor','g')
pause(0.1)
   
    



